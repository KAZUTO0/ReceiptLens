"""ReceiptLens demo: 4 trained fields + prompted numbers + session analytics.

The pretrained LoRA adapters and the four-field benchmark are not changed.
Receipt and phone numbers require an optional *extra* model call and manual
review: SROIE does not supply ground truth for those fields.

History lives in per-visitor Gradio State. Export CSV to keep it across visits.
"""
from __future__ import annotations

import csv
import io
import hashlib
import json
import tempfile
from pathlib import Path
from time import perf_counter

from PIL import Image, ImageEnhance, ImageFilter, ImageOps

from .analytics import (
    CURRENCIES, USER_FIELDS, add_record, export_history, history_rows,
    import_history, make_figures, make_record, summary_markdown,
)
from .extract import parse_json_object, parse_receipt
from .prompts import FIELDS, NUMBER_INSTRUCTION, OPTIONAL_NUMBER_FIELDS
from .vision import predict_receipt


def image_digest(image: Image.Image) -> str:
    buf = io.BytesIO()
    image.convert("RGB").save(buf, format="PNG")
    return hashlib.sha256(buf.getvalue()).hexdigest()


def enhance_image(image: Image.Image) -> Image.Image:
    if image is None:
        raise ValueError("An image is required")
    rgb = ImageOps.exif_transpose(image).convert("RGB")
    contrasted = ImageOps.autocontrast(rgb, cutoff=1)
    contrasted = ImageEnhance.Contrast(contrasted).enhance(1.25)
    return contrasted.filter(ImageFilter.UnsharpMask(radius=1.2, percent=120, threshold=3))


def reviewed_fields(company, date, address, total, receipt_number="", phone_number="") -> dict[str, str]:
    """Return user-reviewed fields; never silently transform phone/receipt IDs to numbers."""
    values = (company, date, address, total, receipt_number, phone_number)
    return {k: ("" if v is None else str(v).strip()) for k, v in zip(USER_FIELDS, values)}


def _spreadsheet_safe(value: str) -> str:
    if value.lstrip().startswith(("=", "+", "-", "@")):
        return "'" + value
    return value


def create_exports(fields: dict[str, str], output_root: str | Path | None = None) -> tuple[str, str]:
    """Download reviewed JSON and CSV, including optional number fields."""
    keys = set(fields)
    if keys not in (set(FIELDS), set(USER_FIELDS)):
        raise ValueError("Expected the four standard fields, optionally plus receipt_number and phone_number")
    order = tuple(k for k in USER_FIELDS if k in keys)
    directory = Path(tempfile.mkdtemp(prefix="receiptlens_", dir=output_root))
    json_path = directory / "receipt.json"
    csv_path = directory / "receipt.csv"
    json_path.write_text(json.dumps(fields, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    with csv_path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(order))
        writer.writeheader()
        writer.writerow({key: _spreadsheet_safe(fields[key]) for key in order})
    return str(json_path), str(csv_path)


def parse_numbers_response(text: str) -> dict[str, str]:
    """Optional inference only, NOT evaluated on SROIE labels."""
    result = {k: "" for k in OPTIONAL_NUMBER_FIELDS}
    payload = parse_json_object(text)
    if not isinstance(payload, dict):
        return result
    for key in OPTIONAL_NUMBER_FIELDS:
        if isinstance(payload.get(key), str):
            result[key] = payload[key].strip()
    return result


def make_demo(model, processor, config, baseline_cache: dict | None = None):
    import gradio as gr

    # Retained argument for compatibility with your previous notebook.
    # A held-out baseline must not be represented as prediction of a new image.
    _ = baseline_cache

    def extract_receipt(image: Image.Image | None, enhance: bool, extract_numbers: bool):
        if image is None:
            raise gr.Error("Upload a receipt image first.")
        prepared = enhance_image(image) if enhance else ImageOps.exif_transpose(image).convert("RGB")
        t0 = perf_counter()
        try:
            fine_text = predict_receipt(
                model, processor, prepared,
                max_edge=config.max_image_edge, max_new_tokens=config.max_new_tokens,
            )
        except Exception as exc:
            raise gr.Error(f"Receipt extraction failed: {type(exc).__name__}: {exc}") from exc
        fine_seconds = perf_counter() - t0
        parsed = parse_receipt(fine_text)
        fields = {key: "" for key in USER_FIELDS}
        if parsed is not None:
            fields.update(parsed)
        notice = []
        if parsed is None:
            notice.append("Four-field JSON was invalid; check raw text and correct fields manually.")
        else:
            missing = [f for f in FIELDS if not fields[f]]
            if missing:
                notice.append("Review blank fields: " + ", ".join(missing) + ".")

        extra_seconds = 0.0
        if extract_numbers:
            start = perf_counter()
            try:
                # A new prompt on the SAME LoRA model; those additional fields
                # are NOT labeled in SROIE and are not benchmarked or reliable.
                # Prefer the original general-purpose model for this *new*
                # task, because LoRA was fine-tuned for exactly four fields.
                # Fall back to the adapter-loaded model if disabling is absent.
                disable_number_adapter = getattr(model, "disable_adapter", None)
                if callable(disable_number_adapter):
                    try:
                        with disable_number_adapter():
                            numbers_text = predict_receipt(
                                model, processor, prepared,
                                max_edge=config.max_image_edge,
                                max_new_tokens=max(128, config.max_new_tokens),
                                instruction=NUMBER_INSTRUCTION,
                            )
                    except Exception:
                        numbers_text = predict_receipt(
                            model, processor, prepared,
                            max_edge=config.max_image_edge,
                            max_new_tokens=max(128, config.max_new_tokens),
                            instruction=NUMBER_INSTRUCTION,
                        )
                else:
                    numbers_text = predict_receipt(
                        model, processor, prepared,
                        max_edge=config.max_image_edge,
                        max_new_tokens=max(128, config.max_new_tokens),
                        instruction=NUMBER_INSTRUCTION,
                    )
                fields.update(parse_numbers_response(numbers_text))
                if not any(fields[key] for key in OPTIONAL_NUMBER_FIELDS):
                    notice.append("Receipt/phone number not detected; enter manually if visible.")
            except Exception as exc:
                notice.append(f"Optional number extraction unavailable ({type(exc).__name__}); edit manually.")
            extra_seconds = perf_counter() - start

        baseline = "Plain model unavailable live; use your saved evaluation CSV."
        disable_adapter = getattr(model, "disable_adapter", None)
        if callable(disable_adapter):
            try:
                with disable_adapter():
                    baseline = predict_receipt(
                        model, processor, prepared,
                        max_edge=config.max_image_edge,
                        max_new_tokens=config.max_new_tokens,
                    )
            except Exception as exc:
                baseline = (f"Plain model unavailable ({type(exc).__name__}); "
                            "refer to baseline CSV.")

        status = (
            f"**Fine-tuned 4-field inference:** {fine_seconds:.2f} s. "
            + (f"**Extra number pass:** {extra_seconds:.2f} s. " if extract_numbers else "")
            + "**Review all values before saving.** " + " ".join(notice)
        )
        return (
            *(fields[k] for k in USER_FIELDS),
            fields, status, baseline, fine_text, None, None,
        )

    def refresh_preview(*values):
        return reviewed_fields(*values), None, None

    def export_fields(*values):
        fields = reviewed_fields(*values)
        if not any(fields.values()):
            raise gr.Error("Extract a receipt or enter reviewed values first.")
        return create_exports(fields)

    def redraw(records, currency):
        fig_month, fig_merchants = make_figures(records, currency)
        return summary_markdown(records, currency), history_rows(records), fig_month, fig_merchants

    def on_save(records, currency, display_currency, *values):
        try:
            record = make_record(reviewed_fields(*values), currency)
        except ValueError as exc:
            raise gr.Error(str(exc)) from exc
        updated = add_record(records, record)
        s, rows, fig_month, fig_merchant = redraw(updated, display_currency)
        return updated, s, rows, fig_month, fig_merchant, (
            f"Saved reviewed receipt #{len(updated)} to your current session. "
            "Download history CSV before refreshing the page."
        ), None

    def on_import(file, records, display_currency):
        if file is None:
            raise gr.Error("Choose a previously exported ReceiptLens history CSV.")
        try:
            updated = import_history(str(file), records)
        except (ValueError, OSError, csv.Error) as exc:
            raise gr.Error(f"Cannot import history: {exc}") from exc
        s, rows, fm, fc = redraw(updated, display_currency)
        return updated, s, rows, fm, fc, f"Loaded {len(updated)} total session receipts.", None

    def on_clear(display_currency):
        s, rows, fm, fc = redraw([], display_currency)
        return [], s, rows, fm, fc, "Session receipt history cleared.", None

    def on_export_history(records):
        if not records:
            raise gr.Error("Save reviewed receipts before exporting a history CSV.")
        return export_history(records)

    history_headers = ["Merchant", "Date", "Total", "Currency", "Receipt #", "Phone"]

    with gr.Blocks(title="ReceiptLens — Receipts & Spending Analysis") as app:
        gr.Markdown(
            "# ReceiptLens\n"
            "**Gemma 4 E2B + LoRA** · Extract receipt information, correct it, "
            "save multiple receipts, and analyze spending.\n\n"
            "**Important:** The original SROIE benchmark covers only company, date, "
            "address and total. Receipt/transaction and phone numbers are **additional prompted guesses**, "
            "not independently fine-tuned or accuracy-tested."
        )
        history_state = gr.State([])  # isolated per browser visitor
        with gr.Tab("1 · Extract and review"):
            with gr.Row():
                with gr.Column(scale=5):
                    receipt = gr.Image(type="pil", label="Upload receipt image")
                    enhance = gr.Checkbox(
                        label="Experimental image contrast/sharpening",
                        value=False,
                        info="May help or harm accuracy. Leave off for benchmark-style inference.",
                    )
                    extract_numbers = gr.Checkbox(
                        label="Also attempt receipt/transaction and phone numbers (extra inference)",
                        value=True,
                        info="Slower; new fields must be verified manually.",
                    )
                    extract_button = gr.Button("Extract receipt", variant="primary")
                    timing_status = gr.Markdown("Upload a receipt to begin.")
                with gr.Column(scale=6):
                    gr.Markdown("### Review and edit results")
                    company = gr.Textbox(label="Company / merchant")
                    date = gr.Textbox(label="Receipt date", placeholder="Prefer YYYY-MM-DD for analysis")
                    address = gr.Textbox(label="Address", lines=2)
                    total = gr.Textbox(label="Total paid", placeholder="e.g. $25.00")
                    receipt_number = gr.Textbox(label="Receipt / transaction number", placeholder="e.g. 80443")
                    phone_number = gr.Textbox(label="Merchant telephone number", placeholder="e.g. 248-9615")
                    reviewed_inputs = [company, date, address, total, receipt_number, phone_number]
                    parsed_json = gr.JSON(label="Current reviewed JSON")
                    export_button = gr.Button("Prepare this receipt's JSON and CSV", variant="secondary")
                    with gr.Row():
                        json_download = gr.File(label="Download JSON", interactive=False)
                        csv_download = gr.File(label="Download CSV", interactive=False)
                    gr.Markdown("### Add reviewed receipt to your analysis")
                    currency = gr.Dropdown(list(CURRENCIES), value="USD", label="Currency for this receipt",
                                           info="Choose correctly; the app does not convert currencies.")
                    save_button = gr.Button("Save reviewed receipt to session", variant="primary")
                    save_status = gr.Markdown("Receipt history is kept separately for each visitor.")
            with gr.Accordion("Plain vs fine-tuned model · raw four-field predictions", open=False):
                with gr.Row():
                    original_raw = gr.Textbox(label="Original Gemma", lines=7, interactive=False)
                    fine_raw = gr.Textbox(label="Fine-tuned Gemma", lines=7, interactive=False)

        with gr.Tab("2 · Spending analysis"):
            gr.Markdown(
                "Analytics use **reviewed receipts that you explicitly save**, not unchecked AI predictions. "
                "Data is per browser session and is **lost on refresh** unless you export a history CSV. "
                "Only compare totals within the same currency. "
                "Ambiguous dates are excluded from the monthly chart."
            )
            analysis_currency = gr.Dropdown(
                list(CURRENCIES), value="USD", label="Analyze this currency only"
            )
            stats = gr.Markdown(summary_markdown([], "USD"))
            history_table = gr.Dataframe(
                value=[], headers=history_headers, interactive=False,
                label="Reviewed receipt history (newest first)",
            )
            with gr.Row():
                monthly_chart = gr.Plot(label="Monthly spending")
                merchants_chart = gr.Plot(label="Top merchants")
            gr.Markdown("### Export or restore your history")
            with gr.Row():
                history_export_button = gr.Button("Download all saved receipts as CSV")
                history_file = gr.File(label="History CSV download", interactive=False)
            with gr.Row():
                history_upload = gr.File(label="Import a ReceiptLens history CSV", file_types=[".csv"], type="filepath")
                history_import_button = gr.Button("Import CSV", variant="secondary")
            clear_history = gr.Button("Clear my session history", variant="secondary")
            analytics_status = gr.Markdown("")

        extract_button.click(
            extract_receipt,
            inputs=[receipt, enhance, extract_numbers],
            outputs=[*reviewed_inputs, parsed_json, timing_status, original_raw,
                     fine_raw, json_download, csv_download],
            concurrency_limit=1,
        )
        for field in reviewed_inputs:
            field.input(
                refresh_preview, inputs=reviewed_inputs,
                outputs=[parsed_json, json_download, csv_download],
            )
        export_button.click(export_fields, inputs=reviewed_inputs,
                            outputs=[json_download, csv_download])
        save_button.click(
            on_save, inputs=[history_state, currency, analysis_currency, *reviewed_inputs],
            outputs=[history_state, stats, history_table, monthly_chart,
                     merchants_chart, save_status, history_file],
        )
        analysis_currency.change(
            redraw, inputs=[history_state, analysis_currency],
            outputs=[stats, history_table, monthly_chart, merchants_chart],
        )
        history_export_button.click(on_export_history, inputs=history_state, outputs=history_file)
        history_import_button.click(
            on_import, inputs=[history_upload, history_state, analysis_currency],
            outputs=[history_state, stats, history_table, monthly_chart,
                     merchants_chart, analytics_status, history_file],
        )
        clear_history.click(
            on_clear, inputs=[analysis_currency],
            outputs=[history_state, stats, history_table, monthly_chart,
                     merchants_chart, analytics_status, history_file],
        )
    return app
