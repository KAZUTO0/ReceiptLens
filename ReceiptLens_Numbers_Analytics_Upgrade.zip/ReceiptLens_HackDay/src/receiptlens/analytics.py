"""Local, per-browser-session receipt review history and spending analysis.

No model inference and no shared server-side receipt database. Only reviewed
fields are retained in Gradio State. Export the session CSV before refresh.
"""
from __future__ import annotations

import csv
import re
import tempfile
import uuid
from collections import defaultdict
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from pathlib import Path

from .prompts import FIELDS

EXTRA_FIELDS = ("receipt_number", "phone_number")
USER_FIELDS = FIELDS + EXTRA_FIELDS
HISTORY_COLUMNS = ("id", "saved_at", "company", "date", "address", "total",
                   "receipt_number", "phone_number", "currency")
CURRENCIES = ("USD", "INR", "MYR", "EUR", "GBP", "Other / unspecified")


def parse_amount(text: object) -> Decimal | None:
    """Accept obvious currency amounts; reject ambiguous and malformed amounts.

    No currency conversion is performed. The UI requires users to choose a
    currency before grouping totals.
    """
    if text is None:
        return None
    raw = str(text).strip()
    if not raw:
        return None
    negative_parentheses = raw.startswith("(") and raw.endswith(")")
    raw = re.sub(r"(?i)(?:USD|INR|MYR|EUR|GBP|RM|RS\.?|RS\s|₹|\$|€|£)", "", raw)
    raw = re.sub(r"\s+", "", raw)
    if negative_parentheses:
        raw = raw.strip("()")
    if not raw or re.search(r"[^0-9,\.\-+]", raw):
        return None
    # Interpret decimal separator only when reasonably unambiguous.
    if "," in raw and "." in raw:
        if raw.rfind(",") > raw.rfind("."):
            # '1.234,56'
            raw = raw.replace(".", "").replace(",", ".")
        else:
            # '1,234.56'
            raw = raw.replace(",", "")
    elif "," in raw:
        segments = raw.split(",")
        if len(segments) == 2 and len(segments[1]) in (1, 2):
            raw = ".".join(segments)
        elif all(len(s) == 3 for s in segments[1:]):
            raw = "".join(segments)
        else:
            return None
    try:
        amount = Decimal(raw)
    except InvalidOperation:
        return None
    if not amount.is_finite():
        return None
    return -abs(amount) if negative_parentheses else amount


def parse_date(text: str) -> str | None:
    """Return ISO date or None for missing / ambiguous human-formatted dates.

    US and Indian date formats such as 03/04/2026 are ambiguous without a
    selected locale: do not silently classify them into the wrong month.
    """
    raw = str(text or "").strip().replace(".", "")
    if not raw:
        return None
    try:
        return datetime.strptime(raw, "%Y-%m-%d").date().isoformat()
    except ValueError:
        pass
    for fmt in ("%b %d, %Y", "%B %d, %Y", "%d %b %Y", "%d %B %Y", "%b %d %Y", "%B %d %Y"):
        try:
            return datetime.strptime(raw, fmt).date().isoformat()
        except ValueError:
            pass
    match = re.fullmatch(r"(\d{1,2})[/\-](\d{1,2})[/\-](\d{4})", raw)
    if match:
        a, b, year = map(int, match.groups())
        if a <= 12 and b <= 12:
            return None  # can be DD/MM or MM/DD
        if a > 12 and b <= 12:
            day, month = a, b
        elif b > 12 and a <= 12:
            month, day = a, b
        else:
            return None
        try:
            return datetime(year, month, day).date().isoformat()
        except ValueError:
            return None
    return None


def make_record(fields: dict[str, object], currency: str) -> dict[str, str]:
    if currency not in CURRENCIES:
        raise ValueError("Choose an allowed currency")
    record = {key: str(fields.get(key, "") or "").strip() for key in USER_FIELDS}
    if not (record["company"] or record["total"] or record["receipt_number"]):
        raise ValueError("Add at least a company, a total, or a receipt number")
    record.update(id=uuid.uuid4().hex, saved_at=datetime.now(timezone.utc).isoformat(timespec="seconds"), currency=currency)
    return record


def add_record(history: list[dict], record: dict[str, str]) -> list[dict]:
    return [*history, record]


def history_rows(records: list[dict]) -> list[list[str]]:
    return [[r.get("company", ""), r.get("date", ""), r.get("total", ""),
             r.get("currency", ""), r.get("receipt_number", ""), r.get("phone_number", "")]
            for r in reversed(records)]


def summarize(records: list[dict], currency: str) -> dict:
    if currency not in CURRENCIES:
        raise ValueError("Invalid currency")
    selected = [r for r in records if r.get("currency") == currency]
    valid = []
    for rec in selected:
        number = parse_amount(rec.get("total", ""))
        if number is not None:
            valid.append((rec, number))
    total = sum((value for _, value in valid), Decimal("0"))
    per_merchant = defaultdict(lambda: Decimal("0"))
    per_month = defaultdict(lambda: Decimal("0"))
    undated = 0
    for rec, amount in valid:
        merchant = rec.get("company", "").strip() or "Unknown merchant"
        per_merchant[merchant] += amount
        date_iso = parse_date(rec.get("date", ""))
        if date_iso:
            per_month[date_iso[:7]] += amount
        else:
            undated += 1
    return {
        "currency": currency,
        "count_all": len(records),
        "count_currency": len(selected),
        "count_valid": len(valid),
        "count_excluded": len(selected) - len(valid),
        "count_undated": undated,
        "total": total,
        "average": total / Decimal(len(valid)) if valid else Decimal("0"),
        "by_merchant": sorted(per_merchant.items(), key=lambda row: row[1], reverse=True),
        "by_month": sorted(per_month.items()),
    }


def summary_markdown(records: list[dict], currency: str) -> str:
    s = summarize(records, currency)
    return (
        f"### {currency} · Reviewed receipts\n"
        f"**{s['count_currency']} receipts** in this currency · "
        f"**{s['count_valid']} valid totals** · "
        f"**Total {s['total']:,.2f}** · **Average {s['average']:,.2f}**\n\n"
        f"{s['count_excluded']} missing or invalid totals excluded from sums. "
        f"{s['count_undated']} receipts with valid amounts excluded from the monthly chart "
        "because their dates are missing or ambiguous. "
        "**Currencies are never combined or converted.**"
    )


def make_figures(records: list[dict], currency: str):
    """Return matplotlib figures or None for empty chart series."""
    import matplotlib.pyplot as plt
    s = summarize(records, currency)
    fig_month, fig_merchant = None, None
    if s["by_month"]:
        months, amounts = zip(*s["by_month"])
        fig_month, ax = plt.subplots(figsize=(7, 3.2))
        ax.bar(months, [float(x) for x in amounts])
        ax.set_title("Monthly total · " + currency)
        ax.set_ylabel("Amount (" + currency + ")")
        ax.tick_params(axis="x", rotation=30)
        fig_month.tight_layout()
    if s["by_merchant"]:
        names, amounts = zip(*s["by_merchant"][:8])
        fig_merchant, ax = plt.subplots(figsize=(7, 3.2))
        ax.barh(list(names)[::-1], [float(x) for x in amounts][::-1])
        ax.set_title("Top merchants · " + currency)
        ax.set_xlabel("Amount (" + currency + ")")
        fig_merchant.tight_layout()
    return fig_month, fig_merchant


def export_history(records: list[dict], output_root: str | Path | None = None) -> str:
    root = Path(tempfile.mkdtemp(prefix="receiptlens_history_", dir=output_root))
    path = root / "receipt_history.csv"
    with path.open("w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.DictWriter(stream, fieldnames=HISTORY_COLUMNS)
        writer.writeheader()
        for record in records:
            writer.writerow({name: _csv_safe(str(record.get(name, ""))) for name in HISTORY_COLUMNS})
    return str(path)


def _csv_safe(value: str) -> str:
    # Discourage spreadsheet formula injection on CSV open.
    if value.lstrip().startswith(("=", "+", "-", "@")):
        return "'" + value
    return value


def import_history(path: str | Path, existing: list[dict] | None = None,
                   max_rows: int = 5000) -> list[dict]:
    existing = list(existing or [])
    previous_ids = {record.get("id") for record in existing}
    with Path(path).open(encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream)
        if not reader.fieldnames or not all(field in reader.fieldnames for field in USER_FIELDS + ("currency",)):
            raise ValueError("Expected ReceiptLens history CSV with reviewed fields and currency")
        for i, row in enumerate(reader):
            if i >= max_rows:
                raise ValueError(f"History import limited to {max_rows} rows")
            # Export escaped potentially dangerous spreadsheet formulas. Only
            # remove escape in trusted exports; preserve values by default.
            currency = row.get("currency", "Other / unspecified")
            if currency not in CURRENCIES:
                continue
            record = {field: str(row.get(field, "") or "").strip() for field in USER_FIELDS}
            record["currency"] = currency
            record["saved_at"] = (row.get("saved_at") or "")[:40]
            raw_id = (row.get("id") or "")[:64]
            record["id"] = raw_id if re.fullmatch("[0-9a-f]{32}", raw_id) else uuid.uuid4().hex
            if record["id"] not in previous_ids:
                existing.append(record)
                previous_ids.add(record["id"])
    return existing
