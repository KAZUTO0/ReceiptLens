"""Model prompts; measured 4-field experimental protocol stays unchanged."""

FIELDS = ("company", "date", "address", "total")
OPTIONAL_NUMBER_FIELDS = ("receipt_number", "phone_number")

RECEIPT_INSTRUCTION = (
    "Read the receipt image carefully. Extract the merchant/company, date, full address, "
    "and final total paid. Return ONLY one JSON object with exactly these keys: "
    '"company", "date", "address", "total". All four values must be strings. '
    "Copy the text faithfully as printed. If a value cannot be read, return an empty string "
    "for that value. Do not guess. Do not include Markdown fences or explanations."
)

# Additional prompted pass: SROIE ground truth does NOT label these fields.
# This is optional, unvalidated on the held-out training benchmark; requires review.
NUMBER_INSTRUCTION = (
    "Inspect the receipt image carefully. Locate (1) the receipt, transaction, invoice, "
    "or check number, and (2) the merchant telephone number. "
    "Return ONLY JSON with exactly these string keys: "
    '{"receipt_number": "", "phone_number": ""}. '
    "Copy only numbers explicitly printed and associated with those meanings. "
    "For receipt_number, prefer a label such as Receipt No, Tran, Transaction, "
    "Invoice No, or Check No; do not substitute terminal numbers, phone numbers, "
    "payment card digits, dates, or prices. "
    "For phone_number, use only an explicitly displayed telephone number. "
    "Leave any field empty if it is missing, unclear or ambiguous. Never invent numbers."
)
